from django.apps import AppConfig


class CuentasConfig(AppConfig):
    name = 'cuentas'
