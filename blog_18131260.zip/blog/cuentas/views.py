from django.shortcuts import render
from django.views import generic
#formulario de django para creación de usuarios
from django.contrib.auth.forms import UserCreationForm
#reverse traduce y redirecciona, reverse_lazy espera a que termine el proceso
from django.urls import reverse_lazy

#Vista para el registro de nuevos usuarios
class VistaRegistro(generic.CreateView):
    form_class = UserCreationForm
    #desppúes de que se crea el usuario, intenta que inicie sesión
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'