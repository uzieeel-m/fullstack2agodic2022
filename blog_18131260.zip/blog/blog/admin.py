from django.contrib import admin
from .models import Publicaciones

# Register your models here.
admin.site.register(Publicaciones)