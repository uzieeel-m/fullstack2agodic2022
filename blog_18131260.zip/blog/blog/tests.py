from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse

from .models import Publicaciones

# Create your tests here.
class PruebasBlog(TestCase):

    def setUp(self):
        self.usuario = get_user_model().objects.create_user(
            username = 'usuarioprueba',
            email = 'prueba@email.com',
            password = 'secreto'
        )
        self.publicacion = Publicaciones.objects.create(
            titulo = 'Titulo prueba',
            cuerpo = 'Cuerpo prueba',
            autor = self.usuario
        )
    
    def test_representacion_cadenas(self):
        pub = Publicaciones(titulo='un titulo simple')
        self.assertEqual(str(pub), pub.titulo)

    def test_contenido_publicacion(self):
        self.assertEqual(f'{self.publicacion.titulo}', 'Titulo prueba')
        self.assertEqual(f'{self.publicacion.autor}', 'usuarioprueba')
        self.assertEqual(f'{self.publicacion.cuerpo}', 'Cuerpo prueba')

    def test_vista_lista_publicaciones(self):
        respuesta = self.client.get(reverse('inicio'))
        self.assertEqual(respuesta.status_code, 200)
        self.assertContains(respuesta, 'Cuerpo prueba')
        self.assertTemplateUsed(respuesta, 'inicio.html')

    def test_vista_detalle_publicacion(self):
        respuesta = self.client.get('/publicacion/1/')
        sin_respuesta = self.client.get('/publicacion/10000/')
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(sin_respuesta.status_code, 404)
        self.assertContains(respuesta, 'Titulo prueba')
        self.assertTemplateUsed(respuesta, 'detalle_publicacion.html')

    def test_vista_crear_publicacion(self):
        respuesta = self.client.post(reverse('nueva_publicacion'), {
            'titulo' : 'Nuevo título',
            'cuerpo' : 'Nuevo texto',
            'autor'  : self.usuario.id,
        })
        self.assertEqual(respuesta.status_code, 302)
        self.assertEqual(Publicaciones.objects.last().titulo, 'Nuevo título')
        self.assertEqual(Publicaciones.objects.last().cuerpo, 'Nuevo texto')

    def test_vista_modificar_publicacion(self):
        #con el args se le mandan argumentos a la url
        #se le manda el '1' pq esta url recibe el id de una publicacion
        #entonces está intentando editar la publicacion 1 de la bd de pruebas
        respuesta = self.client.post(reverse('editar_publicacion', args='1'), {
            'titulo' : 'Título editado',
            'cuerpo' : 'Cuerpo editado',
        })
        self.assertEqual(respuesta.status_code, 302)
        #self.assertEqual(Publicaciones.objects.last().titulo, 'Título editado')
        #self.assertEqual(Publicaciones.objects.last().cuerpo, 'Cuerpo editado')

    def test_vista_eliminar_publicacion(self):
        respuesta = self.client.post(reverse('eliminar_publicacion', args='1'))
        self.assertEqual(respuesta.status_code, 302)