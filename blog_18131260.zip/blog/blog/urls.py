# ./blog/urls
#path se usa para crear las rutas para cada url
from django.urls import path
from .views import VistaListaBlog, VistaDetallePublicacion, VistaCrearBlog, VistaEditarPublicacion, VistaEliminarPublicacion

urlpatterns = [
    path('', VistaListaBlog.as_view(), name='inicio'),
    path('publicacion/<int:pk>/', VistaDetallePublicacion.as_view(), name='detalle_publicacion'),
    path('publicacion/nueva/', VistaCrearBlog.as_view(), name='nueva_publicacion'),
    path('publicacion/<int:pk>/editar/', VistaEditarPublicacion.as_view(), name='editar_publicacion'),
    path('publicacion/<int:pk>/eliminar/', VistaEliminarPublicacion.as_view(), name='eliminar_publicacion'),
]