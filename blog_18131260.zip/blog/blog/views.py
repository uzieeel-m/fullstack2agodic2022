from django.views.generic import ListView, DetailView, UpdateView 
from django.views.generic.edit import CreateView, DeleteView
from .models import Publicaciones
from django.urls import reverse_lazy

# Create your views here.
class VistaListaBlog(ListView):
    model = Publicaciones
    template_name = 'inicio.html'

class VistaDetallePublicacion(DetailView):
    model = Publicaciones
    #enlazar la vista con el html
    template_name = 'detalle_publicacion.html'
    context_object_name = 'publicacion'

class VistaCrearBlog(CreateView):
    model = Publicaciones
    template_name = 'nueva_publicacion.html'
    fields = ['titulo', 'autor', 'cuerpo']

class VistaEditarPublicacion(UpdateView):
    model= Publicaciones
    template_name = 'editar_publicacion.html'
    success_url = reverse_lazy('inicio')
    fields = ['titulo', 'cuerpo']

class VistaEliminarPublicacion(DeleteView):
    model = Publicaciones
    template_name = 'eliminar_publicacion.html'
    success_url= reverse_lazy('inicio')
    context_object_name = 'publicacion'