from django.db import models
# from django.core.urlresolvers import reverse
from django.urls import reverse

# Create your modelos de bases de datos here.
class Publicaciones(models.Model):
    #atributos de la clase (columnas de la tabla)
    titulo = models.CharField(max_length=200)
    autor  = models.ForeignKey(
        #se almacena toda la info del usuario que viene en la tabla auth
        'auth.User',
        on_delete=models.CASCADE
    )
    #campo de texto sin límite
    cuerpo = models.TextField()

    def __str__(self):
        return self.titulo
    
    def get_absolute_url(self):
        return reverse('detalle_publicacion', args=[str(self.id)])